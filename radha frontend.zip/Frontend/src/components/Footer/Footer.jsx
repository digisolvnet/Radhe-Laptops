import { FaFacebookF, FaTwitter, FaInstagram, FaYoutube } from "react-icons/fa";
import Logo from "../../assets/logo.svg";

const Footer = () => {
  return (
    <footer className="w-full">
      {/* Newsletter Section */}
      <div className="bg-blue-100 py-6 text-center">
        <h2 className="text-2xl font-semibold">
          Get our latest news and special sales
        </h2>
        <p className="text-gray-600 mt-2">
          You may unsubscribe at any moment. For that purpose, please find our
          contact info in the legal notice.
        </p>
        <div className="mt-4 flex justify-center">
          <input
            type="email"
            placeholder="Enter your email"
            className="p-2 w-80 border rounded-l-md outline-none"
          />
          <button className="bg-blue-500 text-white px-4 py-2 rounded-r-md">
            Get
          </button>
        </div>
      </div>

      {/* Footer Links Section */}
      <div className="bg-gray-900 text-white py-10 px-4">
        <div className="max-w-6xl mx-auto grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-8 text-center md:text-left">
          {/* Your Account */}

          <div className="flex flex-col sm:flex-col items-center sm:space-x-4 text-center">
            {/* Logo Section */}
            <img
              className="h-20 sm:h-24 w-auto" // Adjust height for different screens
              src={Logo}
              alt="Logo"
            />

            {/* Social Media Section */}
            <div className="mt-4 sm:mt-0 text-center">
              <h5 className="text-sm font-semibold uppercase">Follow us on</h5>
              <div className="flex justify-center space-x-4 pt-2">
                <FaFacebookF className="text-gray-400 hover:text-white cursor-pointer" />
                <FaTwitter className="text-gray-400 hover:text-white cursor-pointer" />
                <FaInstagram className="text-gray-400 hover:text-white cursor-pointer" />
                <FaYoutube className="text-gray-400 hover:text-white cursor-pointer" />
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-semibold uppercase mb-4">
              Featured Products
            </h3>
            <ul className="space-y-2 text-gray-400">
              <li>Hard Disk</li>
              <li>Keyboard</li>
              <li>Mouse</li>
              <li>Ram</li>
              <li>Processor</li>
              <li>Cooling Fan</li>
              <li>Graphic Card</li>
            </ul>
          </div>

          {/* Customer Service */}
          <div>
            <h3 className="text-lg font-semibold uppercase mb-4">
              Laptop Brands
            </h3>
            <p className="text-gray-400">Asus</p>
            <p className="text-gray-400">Lenovo</p>
            <p className="text-gray-400">Mi</p>
            <p className="text-gray-400">Apple</p>
            <p className="text-gray-400">Dell</p>
            <p className="text-gray-400">Hp</p>
            <p className="text-gray-400">Accer</p>
            <p className="text-gray-400">Toshiba</p>
          </div>

          {/* Our Guarantees */}
          <div>
            <h3 className="text-lg font-semibold uppercase mb-4">
              Help & Support
            </h3>
            <ul className="space-y-2 text-gray-400">
              <li>FAQ</li>
              <li>Contact us</li>
              <li>Warranty Policy</li>
              <li>Refund Policy</li>
            </ul>
          </div>

          {/* Our Company */}
          <div>
            <h3 className="text-lg font-semibold uppercase mb-4">More Info</h3>
            <ul className="space-y-2 text-gray-400">
              <li>Term & Conditions</li>
              <li>Privacy Policy</li>
              <li>Terms of Use</li>
            </ul>
          </div>
        </div>

        {/* Payment Icons */}
        <div className="flex space-x-2 text-center justify-center mt-8">
          Copyright @ 2025 Radhe Laptops All rights reserved
        </div>
      </div>
    </footer>
  );
};

export default Footer;
