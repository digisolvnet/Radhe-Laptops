// import { Router } from 'express';
// import { addToCart } from '../controller/custumer/auth.costumer.js';
// // import { authenticateCustomer } from '../auth/auth.js';

// const routes = Router();

// // Add to cart route
// routes.post("/add-to-cart",  addToCart);

// export default routes;
